

#ifndef WIRING_DIGITAL_H_
#define WIRING_DIGITAL_H_


void pinMode(uint32_t pin, uint32_t mode);
void digitalWrite(uint32_t pin, uint32_t value);
uint32_t digitalRead(uint32_t pin);


#endif

