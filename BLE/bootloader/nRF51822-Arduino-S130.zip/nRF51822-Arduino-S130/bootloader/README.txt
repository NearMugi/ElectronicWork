
nRF51822 Bootloader
—--

This bootloader built with S130 SoftDevice and has OTA feature.

*** Please download the whole zip file and use the bootloader.hex file inside.
